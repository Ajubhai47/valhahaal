
import { supabase } from '@/lib/supabase';

// Interface for ML model information
export interface MLModelInfo {
  id: string;
  name: string;
  createdAt: string;
  accuracy: number;
  status: 'training' | 'ready' | 'failed';
}

// Mock function to get ML model information when Supabase doesn't have the proper tables
export async function getMLModels(): Promise<MLModelInfo[]> {
  try {
    // Try to fetch real models from Supabase if the table exists
    const { data, error } = await supabase
      .from('Synthetic_data')
      .select('*')
      .limit(3);
      
    if (error) throw error;
    
    // If we have real data, we'll create mock ML models based on it
    // In a real app, you would have a separate ml_models table
    return [
      {
        id: '1',
        name: 'Keystroke Anomaly Detector',
        createdAt: new Date().toISOString(),
        accuracy: 0.92,
        status: 'ready'
      },
      {
        id: '2',
        name: 'Mouse Movement Analysis',
        createdAt: new Date().toISOString(),
        accuracy: 0.85,
        status: 'ready'
      },
      {
        id: '3',
        name: 'Focus Pattern Detector',
        createdAt: new Date().toISOString(),
        accuracy: 0.78,
        status: 'training'
      }
    ];
  } catch (error) {
    console.error('Error fetching ML models:', error);
    // Return mock data as fallback
    return [
      {
        id: 'mock-1',
        name: 'Keystroke Anomaly Detector (Mock)',
        createdAt: new Date().toISOString(),
        accuracy: 0.92,
        status: 'ready'
      },
      {
        id: 'mock-2',
        name: 'Mouse Movement Analysis (Mock)',
        createdAt: new Date().toISOString(),
        accuracy: 0.85,
        status: 'ready'
      }
    ];
  }
}
