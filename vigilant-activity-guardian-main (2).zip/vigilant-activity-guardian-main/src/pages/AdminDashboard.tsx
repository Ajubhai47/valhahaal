
import { useState, useEffect } from 'react';
import { useActivity } from '@/contexts/ActivityContext';
import { useToast } from '@/components/ui/use-toast';
import { AdminHeader } from '@/components/admin/AdminHeader';
import { AdminTabNavigation } from '@/components/admin/AdminTabNavigation';

const AdminDashboard = () => {
  const { toast } = useToast();
  const { 
    events, 
    isMonitoring, 
    startMonitoring, 
    stopMonitoring,
    totalRiskScore,
    riskLevel,
    totalEvents,
    addTestEvent,
    useDataset,
    toggleDatasetUse
  } = useActivity();
  
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedTab, setSelectedTab] = useState('overview');
  const [totalSessions, setTotalSessions] = useState(28);
  
  // Mock statistics for the admin dashboard
  const stats = {
    activeStudents: 5,
    averageRiskScore: totalRiskScore,
    flaggedSessions: getHighRiskSessionCount(),
    totalSessions: totalSessions
  };

  // Calculate the number of high risk sessions
  function getHighRiskSessionCount() {
    // In a real app, this would come from actual session data
    // For now, we'll just use high risk distribution
    return riskDistribution.high;
  }

  // Risk distribution data (for a real app, this would come from actual data)
  const riskDistribution = {
    low: 3,
    medium: 1,
    high: 1
  };
  
  // Handle creating a new session
  const handleNewSession = () => {
    setTotalSessions(prev => prev + 1);
    toast({
      title: "New session created",
      description: `Session #${totalSessions + 1} has been created successfully.`,
    });
  };
  
  return (
    <div className="min-h-screen bg-gray-50">
      <AdminHeader searchQuery={searchQuery} setSearchQuery={setSearchQuery} />
      
      <div className="container mx-auto px-4 py-8">
        <AdminTabNavigation
          selectedTab={selectedTab}
          setSelectedTab={setSelectedTab}
          stats={stats}
          riskDistribution={riskDistribution}
          isMonitoring={isMonitoring}
          events={events}
          useDataset={useDataset}
          startMonitoring={startMonitoring}
          stopMonitoring={stopMonitoring}
          toggleDatasetUse={toggleDatasetUse}
          addTestEvent={addTestEvent}
          handleNewSession={handleNewSession}
        />
      </div>
    </div>
  );
};

export default AdminDashboard;
