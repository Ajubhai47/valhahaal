
import { useCallback } from 'react';
import { ActivityType, ActivityEvent } from '@/types/activity';
import { useToast } from '@/components/ui/use-toast';

export function useActivityGenerators() {
  const { toast } = useToast();

  // Add a new event
  const addEvent = useCallback((type: ActivityType, details?: string) => {
    // Generate risk score based on activity type (in a real app, ML would do this)
    let riskScore = 10; // Default risk score
    
    switch (type) {
      case 'Tab Switch':
        riskScore = 40;
        break;
      case 'Copy Attempt':
        riskScore = 60;
        break;
      case 'Paste Attempt':
        riskScore = 70;
        break;
      case 'Focus Change':
        riskScore = 30;
        break;
      case 'Session Started':
      case 'Session Ended':
        riskScore = 0;
        break;
    }

    // Add some randomness to the risk score for demo purposes
    const finalRiskScore = Math.min(100, Math.max(0, riskScore + (Math.random() * 20 - 10)));
    
    const newEvent: ActivityEvent = {
      id: Math.random().toString(36).substring(2, 11),
      timestamp: new Date(),
      type,
      details,
      riskScore: finalRiskScore
    };
    
    // Show toast for high-risk events
    if (finalRiskScore > 50) {
      toast({
        title: `High risk ${type} detected`,
        description: `Risk score: ${finalRiskScore.toFixed(0)}%`,
        variant: "destructive",
      });
    }
    
    return newEvent;
  }, [toast]);

  return { addEvent };
}
