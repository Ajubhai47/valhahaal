
import { useState, useEffect } from 'react';
import { ActivityEvent } from '@/types/activity';

export function useActivityRisk(events: ActivityEvent[]) {
  const [totalRiskScore, setTotalRiskScore] = useState(0);
  const [riskLevel, setRiskLevel] = useState<'low' | 'medium' | 'high'>('low');
  const [consecutiveCopyAttempts, setConsecutiveCopyAttempts] = useState(0);
  const [consecutiveFocusChanges, setConsecutiveFocusChanges] = useState(0);
  
  // Count consecutive events of specific types
  useEffect(() => {
    if (events.length < 2) {
      setConsecutiveCopyAttempts(0);
      setConsecutiveFocusChanges(0);
      return;
    }
    
    // Check the most recent events (up to last 10) for patterns
    const recentEvents = events.slice(0, 10);
    
    // Count consecutive copy attempts
    let copyCount = 0;
    for (const event of recentEvents) {
      if (event.type === 'Copy Attempt' || event.type === 'Paste Attempt') {
        copyCount++;
      } else {
        break; // Stop counting when we hit a different event type
      }
    }
    setConsecutiveCopyAttempts(copyCount);
    
    // Count consecutive focus changes
    let focusCount = 0;
    for (const event of recentEvents) {
      if (event.type === 'Focus Change') {
        focusCount++;
      } else {
        break; // Stop counting when we hit a different event type
      }
    }
    setConsecutiveFocusChanges(focusCount);
  }, [events]);

  // Calculate total risk score whenever events change
  useEffect(() => {
    if (events.length === 0) {
      setTotalRiskScore(0);
      return;
    }
    
    // Calculate average risk score across all events
    let avgRiskScore = events.reduce((sum, event) => sum + event.riskScore, 0) / events.length;
    
    // Apply penalty for consecutive suspicious activities - increased maximums
    const copyPenalty = Math.min(30, consecutiveCopyAttempts * 5); // Max +30% penalty (was 15%)
    const focusPenalty = Math.min(20, consecutiveFocusChanges * 3); // Max +20% penalty (was 10%)
    
    // Add penalties to risk score, but cap at 100
    avgRiskScore = Math.min(100, avgRiskScore + copyPenalty + focusPenalty);
    
    setTotalRiskScore(avgRiskScore);
  }, [events, consecutiveCopyAttempts, consecutiveFocusChanges]);

  // Calculate risk level based on total risk score
  useEffect(() => {
    if (totalRiskScore < 30) {
      setRiskLevel('low');
    } else if (totalRiskScore < 70) {
      setRiskLevel('medium');
    } else {
      setRiskLevel('high');
    }
  }, [totalRiskScore]);

  return { 
    totalRiskScore, 
    riskLevel,
    consecutiveCopyAttempts,
    consecutiveFocusChanges
  };
}
