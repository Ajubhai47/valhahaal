
import { useRef, useEffect, useCallback } from 'react';
import { ActivityType } from '@/types/activity';

export function useRealTimeMonitoring(
  isMonitoring: boolean,
  useDataset: boolean,
  addEventCallback: (type: ActivityType, details?: string) => void
) {
  // Refs to track throttling of frequent events
  const lastMouseMoveTime = useRef<number>(0);
  const lastKeyTime = useRef<number>(0);
  const mouseMovementCounter = useRef<number>(0);
  const keyCounter = useRef<number>(0);
  
  // Setup browser event listeners for real-time activity monitoring
  useEffect(() => {
    if (!isMonitoring || useDataset) return;

    // Handler for mouse movements
    const handleMouseMove = () => {
      const now = Date.now();
      mouseMovementCounter.current += 1;
      
      // Throttle mouse movement events to avoid flooding
      if (now - lastMouseMoveTime.current > 5000) { // Report every 5 seconds if there's movement
        if (mouseMovementCounter.current > 10) { // Only if there's significant movement
          addEventCallback('Mouse Movement', `Detected ${mouseMovementCounter.current} movements`);
        }
        lastMouseMoveTime.current = now;
        mouseMovementCounter.current = 0;
      }
    };

    // Handler for keyboard activity
    const handleKeyDown = () => {
      const now = Date.now();
      keyCounter.current += 1;
      
      // Throttle keyboard events
      if (now - lastKeyTime.current > 5000) { // Report every 5 seconds of typing
        if (keyCounter.current > 5) { // Only if there's significant typing
          addEventCallback('Keyboard Activity', `Detected ${keyCounter.current} keystrokes`);
        }
        lastKeyTime.current = now;
        keyCounter.current = 0;
      }
    };

    // Handler for tab/window visibility changes
    const handleVisibilityChange = () => {
      if (document.hidden) {
        addEventCallback('Focus Change', 'Lost focus from application');
      } else {
        addEventCallback('Focus Change', 'Returned focus to application');
      }
    };

    // Handler for copy attempts
    const handleCopy = () => {
      addEventCallback('Copy Attempt', 'User attempted to copy content');
    };

    // Handler for paste attempts
    const handlePaste = () => {
      addEventCallback('Paste Attempt', 'User attempted to paste content');
    };

    // Add all event listeners
    document.addEventListener('mousemove', handleMouseMove);
    document.addEventListener('keydown', handleKeyDown);
    document.addEventListener('visibilitychange', handleVisibilityChange);
    document.addEventListener('copy', handleCopy);
    document.addEventListener('paste', handlePaste);
    
    // Remove all listeners on cleanup
    return () => {
      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('keydown', handleKeyDown);
      document.removeEventListener('visibilitychange', handleVisibilityChange);
      document.removeEventListener('copy', handleCopy);
      document.removeEventListener('paste', handlePaste);
    };
  }, [isMonitoring, useDataset, addEventCallback]);
}
