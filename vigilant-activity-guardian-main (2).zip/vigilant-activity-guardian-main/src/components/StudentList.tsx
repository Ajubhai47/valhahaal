
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";

// Mock student data
const mockStudents = [
  {
    id: "STD001",
    name: "Jane Cooper",
    exam: "Advanced Mathematics",
    timeElapsed: "32:45",
    riskScore: 12,
    status: "active"
  },
  {
    id: "STD002",
    name: "Alex Johnson",
    exam: "Computer Science 101",
    timeElapsed: "45:12",
    riskScore: 68,
    status: "flagged"
  },
  {
    id: "STD003",
    name: "Michael Wilson",
    exam: "Introduction to Physics",
    timeElapsed: "15:30",
    riskScore: 5,
    status: "active"
  },
  {
    id: "STD004",
    name: "Emily Davis",
    exam: "English Literature",
    timeElapsed: "52:18",
    riskScore: 87,
    status: "high-risk"
  },
  {
    id: "STD005",
    name: "Robert Brown",
    exam: "World History",
    timeElapsed: "28:55",
    riskScore: 24,
    status: "active"
  }
];

interface StudentListProps {
  extended?: boolean;
}

export const StudentList = ({ extended = false }: StudentListProps) => {
  const getRiskBadge = (riskScore: number) => {
    if (riskScore < 30) {
      return <Badge variant="outline" className="bg-green-100 text-green-700 hover:bg-green-100 border-0">Low Risk</Badge>;
    } else if (riskScore < 70) {
      return <Badge variant="outline" className="bg-yellow-100 text-yellow-700 hover:bg-yellow-100 border-0">Medium Risk</Badge>;
    } else {
      return <Badge variant="outline" className="bg-red-100 text-red-700 hover:bg-red-100 border-0">High Risk</Badge>;
    }
  };
  
  const getStatusBadge = (status: string) => {
    switch (status) {
      case "active":
        return <Badge variant="outline" className="bg-green-100 text-green-700 hover:bg-green-100 border-0">Active</Badge>;
      case "flagged":
        return <Badge variant="outline" className="bg-yellow-100 text-yellow-700 hover:bg-yellow-100 border-0">Flagged</Badge>;
      case "high-risk":
        return <Badge variant="outline" className="bg-red-100 text-red-700 hover:bg-red-100 border-0">High Risk</Badge>;
      default:
        return <Badge variant="outline" className="bg-gray-100 text-gray-700 hover:bg-gray-100 border-0">Unknown</Badge>;
    }
  };
  
  return (
    <Table>
      <TableHeader>
        <TableRow>
          <TableHead>Student ID</TableHead>
          <TableHead>Name</TableHead>
          <TableHead>Exam</TableHead>
          {extended && <TableHead>Status</TableHead>}
          <TableHead>Time Elapsed</TableHead>
          <TableHead>Risk Level</TableHead>
        </TableRow>
      </TableHeader>
      <TableBody>
        {mockStudents.map((student) => (
          <TableRow key={student.id}>
            <TableCell className="font-medium">{student.id}</TableCell>
            <TableCell>{student.name}</TableCell>
            <TableCell>{student.exam}</TableCell>
            {extended && <TableCell>{getStatusBadge(student.status)}</TableCell>}
            <TableCell>{student.timeElapsed}</TableCell>
            <TableCell>{getRiskBadge(student.riskScore)}</TableCell>
          </TableRow>
        ))}
      </TableBody>
    </Table>
  );
};
