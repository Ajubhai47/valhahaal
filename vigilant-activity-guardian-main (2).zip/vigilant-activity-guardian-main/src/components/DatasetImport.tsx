import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Upload, FileCheck, AlertCircle, Database } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useActivity } from '@/contexts/ActivityContext';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { supabase, isSupabaseConfigured } from '@/lib/supabase';

export const DatasetImport = () => {
  const [file, setFile] = useState<File | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [progress, setProgress] = useState(0);
  const [datasets, setDatasets] = useState<{id: string, name: string}[]>([]);
  const [selectedDataset, setSelectedDataset] = useState<string>('');
  const [loadingSupabase, setLoadingSupabase] = useState(false);
  const [supabaseConfigured, setSupabaseConfigured] = useState(false);
  const { toast } = useToast();
  const { importDataset } = useActivity();
  
  useEffect(() => {
    // Check if Supabase is properly configured
    setSupabaseConfigured(isSupabaseConfigured());

    // Fetch available datasets from Supabase
    const fetchDatasets = async () => {
      try {
        setLoadingSupabase(true);
        
        if (!isSupabaseConfigured()) {
          throw new Error('Supabase is not properly configured');
        }
        
        // Using the Synthetic_data table to create mock datasets
        const { data, error } = await supabase
          .from('Synthetic_data')
          .select('*')
          .limit(10);
        
        if (error) throw error;
        
        // Create mock dataset entries since we don't have a datasets table
        const mockDatasets = [
          { id: '1', name: 'Exam Session Dataset #1' },
          { id: '2', name: 'Mouse Activity Dataset' },
          { id: '3', name: 'Keystroke Patterns' },
        ];
        
        setDatasets(mockDatasets);
        
        toast({
          title: "Connected to Supabase",
          description: `Found synthetic data to use`,
        });
      } catch (error) {
        console.error('Error fetching datasets:', error);
        toast({
          title: "Error connecting to Supabase",
          description: "Could not retrieve datasets. Check your connection settings.",
          variant: "destructive",
        });
        
        // Fallback to mock data
        const mockData = [
          { id: '1', name: 'Exam Session Dataset #1 (Mock)' },
          { id: '2', name: 'Mouse Activity Dataset (Mock)' },
          { id: '3', name: 'Keystroke Patterns (Mock)' },
        ];
        
        setDatasets(mockData);
      } finally {
        setLoadingSupabase(false);
      }
    };
    
    fetchDatasets();
  }, [toast]);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      setFile(e.target.files[0]);
    }
  };
  
  const handleDatasetSelect = (value: string) => {
    setSelectedDataset(value);
  };
  
  const handleImportFromSupabase = async () => {
    if (!selectedDataset) {
      toast({
        title: "No dataset selected",
        description: "Please select a dataset from the dropdown",
        variant: "destructive",
      });
      return;
    }
    
    setIsLoading(true);
    setProgress(10);
    
    try {
      // Fetch actual data from Synthetic_data table
      const { data, error } = await supabase
        .from('Synthetic_data')
        .select('*')
        .limit(20);
      
      if (error) throw error;
      
      setProgress(50);
      
      if (!data || data.length === 0) {
        throw new Error('No records found for this dataset');
      }
      
      // Transform the Synthetic_data to match the expected ActivityEvent format
      const formattedData = data.map(record => {
        const now = new Date();
        now.setMinutes(now.getMinutes() - Math.floor(Math.random() * 60));
        
        const activityTypes = ['Focus Change', 'Mouse Movement', 'Keyboard Activity', 'Tab Switch', 'Copy Attempt', 'Paste Attempt'];
        const randomType = activityTypes[Math.floor(Math.random() * activityTypes.length)];
        
        return {
          timestamp: now.toISOString(),
          type: randomType,
          details: `${randomType} with risk level ${record["Risk Level"]}`,
          riskScore: record["Anomaly Score"] || Math.floor(Math.random() * 100)
        };
      });
      
      setProgress(90);
      
      // Import the dataset
      importDataset(formattedData);
      
      setProgress(100);
      
      toast({
        title: "Dataset imported from Supabase",
        description: `Successfully imported ${formattedData.length} activity records`,
      });
    } catch (error) {
      console.error('Supabase import error:', error);
      
      // Fallback to mock data if there was an error
      const mockData = Array(20).fill(null).map((_, i) => ({
        timestamp: new Date(Date.now() - i * 60000).toISOString(),
        type: ['Focus Change', 'Mouse Movement', 'Keyboard Activity', 'Tab Switch', 'Copy Attempt'][Math.floor(Math.random() * 5)],
        details: `Activity from Supabase dataset ${selectedDataset} (Mock)`,
        riskScore: Math.floor(Math.random() * 100)
      }));
      
      // Import the mock dataset
      importDataset(mockData);
      
      toast({
        title: "Using mock data",
        description: "Failed to import from Supabase. Using mock data instead.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
      setTimeout(() => setProgress(0), 1000);
    }
  };
  
  const handleImportFromFile = async () => {
    if (!file) {
      toast({
        title: "No file selected",
        description: "Please select a dataset file to import",
        variant: "destructive",
      });
      return;
    }
    
    // Check if file is JSON or CSV
    if (!file.name.endsWith('.json') && !file.name.endsWith('.csv')) {
      toast({
        title: "Invalid file format",
        description: "Please upload a JSON or CSV file",
        variant: "destructive",
      });
      return;
    }
    
    setIsLoading(true);
    
    try {
      // Start reading file
      const reader = new FileReader();
      
      reader.onprogress = (event) => {
        if (event.lengthComputable) {
          const percentComplete = Math.round((event.loaded / event.total) * 100);
          setProgress(percentComplete);
        }
      };
      
      reader.onload = async (e) => {
        try {
          let data;
          
          // Parse file based on type
          if (file.name.endsWith('.json')) {
            data = JSON.parse(e.target?.result as string);
          } else {
            // Simple CSV parsing
            const text = e.target?.result as string;
            data = text.split('\n').map(line => {
              const values = line.split(',');
              return {
                timestamp: values[0],
                type: values[1],
                details: values[2],
                riskScore: parseFloat(values[3] || '0')
              };
            });
            // Remove header row if it exists
            if (data.length > 0 && isNaN(data[0].riskScore)) {
              data.shift();
            }
          }
          
          // Import dataset using context function
          importDataset(data);
          
          toast({
            title: "Dataset imported",
            description: `Successfully imported ${data.length} activity records`,
          });
        } catch (error) {
          console.error('Error parsing dataset:', error);
          toast({
            title: "Error parsing dataset",
            description: "The file format is not valid. Please check your data structure.",
            variant: "destructive",
          });
        } finally {
          setIsLoading(false);
          setProgress(0);
        }
      };
      
      reader.onerror = () => {
        toast({
          title: "Error reading file",
          description: "Could not read the dataset file",
          variant: "destructive",
        });
        setIsLoading(false);
        setProgress(0);
      };
      
      reader.readAsText(file);
    } catch (error) {
      console.error('Import error:', error);
      toast({
        title: "Import failed",
        description: "Failed to import dataset",
        variant: "destructive",
      });
      setIsLoading(false);
      setProgress(0);
    }
  };
  
  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Upload size={18} /> Import Activity Dataset
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-6">
          {/* Supabase Dataset Selection */}
          <div className="p-4 border rounded-lg bg-gray-50">
            <h3 className="text-sm font-medium flex items-center gap-2 mb-4">
              <Database size={16} className="text-ethicproc-700" />
              Import from Supabase
            </h3>
            
            {!supabaseConfigured && (
              <div className="mb-4 p-3 bg-amber-50 border border-amber-200 rounded-md text-amber-800">
                <div className="flex items-start">
                  <AlertCircle className="w-5 h-5 mr-2 shrink-0" />
                  <div>
                    <p className="font-medium mb-1">Supabase configuration needed</p>
                    <p className="text-sm">
                      Set the VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY environment variables to connect to your Supabase project.
                    </p>
                  </div>
                </div>
              </div>
            )}
            
            <div className="space-y-4">
              <div className="space-y-2">
                <label className="text-sm text-gray-500">Select Dataset</label>
                <Select 
                  value={selectedDataset} 
                  onValueChange={handleDatasetSelect}
                  disabled={loadingSupabase || isLoading || !supabaseConfigured}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select a dataset" />
                  </SelectTrigger>
                  <SelectContent>
                    {datasets.map(dataset => (
                      <SelectItem key={dataset.id} value={dataset.id}>
                        {dataset.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              <Button 
                onClick={handleImportFromSupabase}
                disabled={!selectedDataset || isLoading || !supabaseConfigured}
                className="bg-ethicproc-700 hover:bg-ethicproc-800 w-full"
              >
                {isLoading ? 'Importing...' : 'Import from Supabase'}
              </Button>
            </div>
          </div>
          
          {/* Local File Upload */}
          <div className="p-4 border rounded-lg">
            <h3 className="text-sm font-medium flex items-center gap-2 mb-4">
              <Upload size={16} /> Import from Local File
            </h3>
            
            <div className="flex items-center justify-center w-full">
              <label 
                htmlFor="dataset-upload" 
                className="flex flex-col items-center justify-center w-full h-32 border-2 border-dashed rounded-lg cursor-pointer bg-gray-50 hover:bg-gray-100 border-gray-300"
              >
                <div className="flex flex-col items-center justify-center pt-5 pb-6">
                  {file ? (
                    <>
                      <FileCheck className="w-8 h-8 mb-2 text-green-500" />
                      <p className="text-sm text-gray-500">{file.name}</p>
                      <p className="text-xs text-gray-400">{(file.size / 1024).toFixed(2)} KB</p>
                    </>
                  ) : (
                    <>
                      <Upload className="w-8 h-8 mb-2 text-gray-400" />
                      <p className="text-sm text-gray-500">
                        <span className="font-semibold">Click to upload</span> or drag and drop
                      </p>
                      <p className="text-xs text-gray-400">JSON or CSV format (Max 10MB)</p>
                    </>
                  )}
                </div>
                <input 
                  id="dataset-upload" 
                  type="file" 
                  className="hidden" 
                  accept=".json,.csv" 
                  onChange={handleFileChange}
                  disabled={isLoading}
                />
              </label>
            </div>
            
            <Button 
              onClick={handleImportFromFile}
              disabled={!file || isLoading}
              className="bg-ethicproc-700 hover:bg-ethicproc-800 w-full mt-4"
            >
              {isLoading ? 'Importing...' : 'Import from File'}
            </Button>
          </div>
          
          {isLoading && (
            <div className="space-y-2">
              <div className="flex justify-between text-xs">
                <span>Importing...</span>
                <span>{progress}%</span>
              </div>
              <Progress value={progress} className="h-2" />
            </div>
          )}
          
          <div className="flex items-start mt-3 text-xs text-gray-500">
            <AlertCircle className="shrink-0 w-4 h-4 mr-1.5 text-gray-400" />
            <p>
              Your dataset should contain activity records with timestamp, type, details, and risk score fields.
              When using Supabase, you can also train ML models on your data for more accurate risk assessment.
            </p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};
