
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { StudentList } from '@/components/StudentList';
import { Search } from 'lucide-react';

export const StudentsTab = () => {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Student Management</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="flex mb-4 gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-2 top-1/2 transform -translate-y-1/2 text-gray-400" size={16} />
            <Input 
              placeholder="Search students..." 
              className="pl-8"
            />
          </div>
          <Button className="bg-ethicproc-700 hover:bg-ethicproc-800">Add Student</Button>
        </div>
        
        <StudentList extended />
      </CardContent>
    </Card>
  );
};
