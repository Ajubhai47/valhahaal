
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

export const ReportsTab = () => {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Reporting Dashboard</CardTitle>
      </CardHeader>
      <CardContent>
        <p className="text-gray-500 mb-4">
          View and export detailed reports on student activities and risk assessments.
        </p>
        
        <div className="flex gap-4 mb-8">
          <Button variant="outline">Daily Reports</Button>
          <Button variant="outline">Weekly Summary</Button>
          <Button variant="outline">Export Data</Button>
        </div>
        
        <div className="border p-8 rounded-lg bg-gray-50 text-center">
          <p className="text-gray-500">
            Detailed reporting functionality will be available in the full version.
          </p>
        </div>
      </CardContent>
    </Card>
  );
};
