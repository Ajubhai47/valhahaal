
import { supabase } from '@/integrations/supabase/client';

// Helper function to check if Supabase is properly configured
export const isSupabaseConfigured = () => {
  return true; // We're now using the properly configured client from the integration
};

// Export the client from the integration
export { supabase };
